package com.htmlapk.shell;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

/**
 * Shows the bundled web app (assets/www) full-window. Files are served from
 * https://appassets.androidplatform.net/ so that storage, fetch() and modules work.
 */
public class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private static final String BASE = "https://" + HOST + "/";
    private static final int REQ_FILE = 101;
    private static final int REQ_SAVE = 102;

    private static final String INJECT = "<script>(function(){if(window.__htmlApk)return;window.__htmlApk=true;"
            + "try{var r=URL.revokeObjectURL.bind(URL);URL.revokeObjectURL=function(u){setTimeout(function(){r(u);},120000);};}catch(e){}"
            + "try{var c=HTMLAnchorElement.prototype.click;HTMLAnchorElement.prototype.click=function(){"
            + "if(this.hasAttribute('download')){window.__htmlApkName=this.getAttribute('download')||null;}return c.apply(this,arguments);};}catch(e){}"
            + "document.addEventListener('click',function(e){var a=e.target&&e.target.closest?e.target.closest('a[download]'):null;"
            + "if(a){window.__htmlApkName=a.getAttribute('download')||null;}},true);})();</script>";

    private WebView web;
    private String entry = "index.html";
    private ValueCallback<Uri[]> fileCallback;
    private byte[] pendingSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Properties config = new Properties();
        try (InputStream in = getAssets().open("htmlapk.properties")) {
            config.load(in);
        } catch (IOException ignored) {
        }
        entry = config.getProperty("entry", "index.html");
        boolean fullscreen = "true".equals(config.getProperty("fullscreen", "false"));
        if (fullscreen) {
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                    WindowManager.LayoutParams.FLAG_FULLSCREEN);
            hideSystemBars();
        }

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setTextZoom(100);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        web.setWebViewClient(new ShellClient());
        web.setWebChromeClient(new ShellChrome());
        web.addJavascriptInterface(new Bridge(), "HtmlApkBridge");
        web.setDownloadListener((url, userAgent, contentDisposition, mimeType, length) ->
                handleDownload(url, contentDisposition, mimeType));
        FrameLayout container = new FrameLayout(this);
        container.setBackgroundColor(Color.WHITE);
        container.setFitsSystemWindows(!fullscreen);
        container.addView(web, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(container);

        if (savedInstanceState != null) web.restoreState(savedInstanceState);
        if (web.getUrl() == null) web.loadUrl(BASE + entry);
    }

    private void hideSystemBars() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && (getWindow().getAttributes().flags & WindowManager.LayoutParams.FLAG_FULLSCREEN) != 0) {
            hideSystemBars();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (web != null) web.saveState(outState);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (web != null) web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    // ------------------------------------------------------------ local files

    private final class ShellClient extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            Uri url = request.getUrl();
            if (!HOST.equals(url.getHost())) return null;
            String path = url.getPath();
            if (path == null || path.equals("/") || path.isEmpty()) path = "/" + entry;
            if (path.endsWith("/")) path += "index.html";
            path = path.substring(1);
            Map<String, String> headers = new HashMap<>();
            headers.put("Access-Control-Allow-Origin", "*");
            headers.put("Cache-Control", "no-cache");
            try {
                byte[] data = readAll(getAssets().open("www/" + path));
                String mime = mimeFor(path);
                if (mime.equals("text/html")) data = injectHelper(data);
                String encoding = isText(mime) ? "UTF-8" : null;
                return new WebResourceResponse(mime, encoding, 200, "OK", headers,
                        new ByteArrayInputStream(data));
            } catch (IOException e) {
                return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", headers,
                        new ByteArrayInputStream(("Not found: " + path).getBytes(StandardCharsets.UTF_8)));
            }
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            Uri url = request.getUrl();
            if (HOST.equals(url.getHost())) return false;
            if (!request.isForMainFrame()) return false;
            String scheme = url.getScheme() == null ? "" : url.getScheme().toLowerCase(Locale.ROOT);
            if (scheme.equals("blob") || scheme.equals("data") || scheme.equals("about")
                    || scheme.equals("javascript")) {
                return false;
            }
            openExternal(url);
            return true;
        }
    }

    /** Inserts a small helper script right after <head> (keeps the page's own bytes intact). */
    private static byte[] injectHelper(byte[] html) {
        String text = new String(html, StandardCharsets.ISO_8859_1);
        String lower = text.toLowerCase(Locale.ROOT);
        int at = tagEnd(lower, "<head");
        if (at < 0) at = tagEnd(lower, "<html");
        if (at < 0) {
            int doctype = lower.indexOf("<!doctype");
            at = doctype >= 0 ? lower.indexOf('>', doctype) + 1 : 0;
        }
        String result = text.substring(0, at) + INJECT + text.substring(at);
        return result.getBytes(StandardCharsets.ISO_8859_1);
    }

    private static int tagEnd(String lower, String tag) {
        int i = lower.indexOf(tag);
        while (i >= 0) {
            int next = i + tag.length();
            if (next < lower.length()) {
                char c = lower.charAt(next);
                if (c == '>' || c == ' ' || c == '\t' || c == '\n' || c == '\r') {
                    int close = lower.indexOf('>', i);
                    return close < 0 ? -1 : close + 1;
                }
            }
            i = lower.indexOf(tag, next);
        }
        return -1;
    }

    private static boolean isText(String mime) {
        return mime.startsWith("text/") || mime.equals("application/javascript")
                || mime.equals("application/json") || mime.equals("image/svg+xml")
                || mime.equals("application/xml");
    }

    private static String mimeFor(String path) {
        int dot = path.lastIndexOf('.');
        String ext = dot >= 0 ? path.substring(dot + 1).toLowerCase(Locale.ROOT) : "";
        switch (ext) {
            case "html":
            case "htm":
                return "text/html";
            case "js":
            case "mjs":
                return "application/javascript";
            case "css":
                return "text/css";
            case "json":
            case "map":
                return "application/json";
            case "svg":
                return "image/svg+xml";
            case "wasm":
                return "application/wasm";
            case "txt":
                return "text/plain";
            case "xml":
                return "application/xml";
            case "woff":
                return "font/woff";
            case "woff2":
                return "font/woff2";
            case "ttf":
                return "font/ttf";
            case "otf":
                return "font/otf";
            case "ico":
                return "image/x-icon";
            default:
                String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
                return m != null ? m : "application/octet-stream";
        }
    }

    // ------------------------------------------------------- file uploads

    private final class ShellChrome extends WebChromeClient {
        @Override
        public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                         FileChooserParams params) {
            if (fileCallback != null) fileCallback.onReceiveValue(null);
            fileCallback = callback;
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("*/*");
            String[] mimes = acceptedMimeTypes(params.getAcceptTypes());
            if (mimes.length > 0) intent.putExtra(Intent.EXTRA_MIME_TYPES, mimes);
            if (params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) {
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            }
            try {
                startActivityForResult(intent, REQ_FILE);
                return true;
            } catch (ActivityNotFoundException e) {
                fileCallback = null;
                toast("No file picker available");
                return false;
            }
        }
    }

    private static String[] acceptedMimeTypes(String[] accept) {
        List<String> out = new ArrayList<>();
        if (accept != null) {
            for (String group : accept) {
                if (group == null) continue;
                for (String raw : group.split(",")) {
                    String a = raw.trim().toLowerCase(Locale.ROOT);
                    if (a.isEmpty()) continue;
                    String mime = a.startsWith(".")
                            ? MimeTypeMap.getSingleton().getMimeTypeFromExtension(a.substring(1))
                            : (a.contains("/") ? a : null);
                    if (mime == null) return new String[0]; // unknown type: allow everything
                    if (!out.contains(mime)) out.add(mime);
                }
            }
        }
        return out.toArray(new String[0]);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE) {
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null) {
                ClipData clip = data.getClipData();
                if (clip != null && clip.getItemCount() > 0) {
                    result = new Uri[clip.getItemCount()];
                    for (int i = 0; i < clip.getItemCount(); i++) result[i] = clip.getItemAt(i).getUri();
                } else if (data.getData() != null) {
                    result = new Uri[]{data.getData()};
                }
            }
            if (fileCallback != null) fileCallback.onReceiveValue(result);
            fileCallback = null;
        } else if (requestCode == REQ_SAVE) {
            byte[] bytes = pendingSave;
            pendingSave = null;
            if (resultCode != RESULT_OK || data == null || data.getData() == null || bytes == null) return;
            try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                if (out == null) throw new IOException("Cannot open file");
                out.write(bytes);
                toast("Saved");
            } catch (IOException e) {
                toast("Save failed: " + e.getMessage());
            }
        }
    }

    // ---------------------------------------------------------- downloads

    private void handleDownload(String url, String contentDisposition, String mimeType) {
        String guessed = URLUtil.guessFileName(url, contentDisposition, mimeType);
        String mime = (mimeType == null || mimeType.isEmpty()) ? "application/octet-stream" : mimeType;
        if (url.startsWith("blob:") || url.startsWith("data:")) {
            String js = "(function(){var n=window.__htmlApkName||" + JSONObject.quote(guessed) + ";"
                    + "window.__htmlApkName=null;"
                    + "fetch(" + JSONObject.quote(url) + ").then(function(r){return r.blob();})"
                    + ".then(function(b){var f=new FileReader();f.onloadend=function(){"
                    + "HtmlApkBridge.save(String(f.result),n,b.type||" + JSONObject.quote(mime) + ");};"
                    + "f.readAsDataURL(b);})"
                    + ".catch(function(e){HtmlApkBridge.failed(String(e));});})();";
            web.evaluateJavascript(js, null);
        } else if (url.startsWith(BASE)) {
            String path = Uri.parse(url).getPath();
            try {
                byte[] data = readAll(getAssets().open("www" + path));
                startSave(data, guessed, mime);
            } catch (IOException e) {
                toast("Download failed");
            }
        } else {
            openExternal(Uri.parse(url));
        }
    }

    public final class Bridge {
        @JavascriptInterface
        public void save(String dataUrl, String name, String mime) {
            int comma = dataUrl.indexOf(',');
            byte[] bytes = Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT);
            String fileName = (name == null || name.isEmpty() || name.equals("null")) ? "download" : name;
            runOnUiThread(() -> startSave(bytes, fileName, mime));
        }

        @JavascriptInterface
        public void failed(String message) {
            runOnUiThread(() -> toast("Download failed: " + message));
        }
    }

    private void startSave(byte[] bytes, String name, String mime) {
        pendingSave = bytes;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(mime == null || mime.isEmpty() ? "application/octet-stream" : mime);
        intent.putExtra(Intent.EXTRA_TITLE, name);
        try {
            startActivityForResult(intent, REQ_SAVE);
        } catch (ActivityNotFoundException e) {
            pendingSave = null;
            toast("Cannot save files on this device");
        }
    }

    // -------------------------------------------------------------- helpers

    private void openExternal(Uri url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, url));
        } catch (ActivityNotFoundException e) {
            toast("No app can open this link");
        }
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private static byte[] readAll(InputStream in) throws IOException {
        try (InputStream input = in) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = input.read(buf)) != -1) out.write(buf, 0, n);
            return out.toByteArray();
        }
    }
}
