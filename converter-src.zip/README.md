# HTML to APK Converter (on-phone)

Two Android apps in one project:

- `template/` – a WebView shell that shows `assets/www/index.html`.
- `app/` – the converter. It carries the template APK, swaps in your web files,
  app name, package name, version and icon, then signs the new APK on the phone
  (using Google's `apksig` library) and installs it.

GitHub Actions builds the template first, embeds it in the converter, builds the
converter, and then runs a self-test that generates and verifies a sample app.

Artifacts per run:
- `HtmlToApkConverter` – install this on your phone.
- `SampleGeneratedApp` – an app produced by the converter's code during the self-test.
