package com.htmlapk.converter.core;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.PKCS8EncodedKeySpec;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** Creates and stores the signing key used for generated apps (no external libraries). */
public final class CertGen {
    public static final class SigningKey {
        public final PrivateKey privateKey;
        public final X509Certificate certificate;

        SigningKey(PrivateKey privateKey, X509Certificate certificate) {
            this.privateKey = privateKey;
            this.certificate = certificate;
        }
    }

    private CertGen() {
    }

    /** Loads the key from dir, or creates and saves a new one the first time. */
    public static synchronized SigningKey loadOrCreate(File dir) throws Exception {
        File keyFile = new File(dir, "key.pk8");
        File certFile = new File(dir, "cert.der");
        if (keyFile.isFile() && certFile.isFile()) {
            byte[] keyBytes = Files.readAllBytes(keyFile.toPath());
            PrivateKey key = KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(keyBytes));
            X509Certificate cert = parseCert(Files.readAllBytes(certFile.toPath()));
            return new SigningKey(key, cert);
        }
        if (!dir.isDirectory() && !dir.mkdirs()) throw new IOException("Cannot create " + dir);
        KeyPairGenerator gen = KeyPairGenerator.getInstance("RSA");
        gen.initialize(2048, new SecureRandom());
        KeyPair pair = gen.generateKeyPair();
        byte[] certDer = selfSign(pair, "HTML to APK Converter", 30);
        Files.write(keyFile.toPath(), pair.getPrivate().getEncoded());
        Files.write(certFile.toPath(), certDer);
        return new SigningKey(pair.getPrivate(), parseCert(certDer));
    }

    static X509Certificate parseCert(byte[] der) throws Exception {
        return (X509Certificate) CertificateFactory.getInstance("X.509")
                .generateCertificate(new ByteArrayInputStream(der));
    }

    static byte[] selfSign(KeyPair pair, String commonName, int years) throws Exception {
        byte[] sigAlg = seq(oid(1, 2, 840, 113549, 1, 1, 11), new byte[]{0x05, 0x00});
        byte[] name = seq(tlv(0x31, seq(oid(2, 5, 4, 3),
                tlv(0x0c, commonName.getBytes(StandardCharsets.UTF_8)))));
        long now = System.currentTimeMillis();
        Date notBefore = new Date(now - 24L * 3600 * 1000);
        Date notAfter = new Date(now + years * 365L * 24 * 3600 * 1000);
        BigInteger serial = new BigInteger(63, new SecureRandom()).add(BigInteger.ONE);

        byte[] version = tlv(0xa0, tlv(0x02, new byte[]{0x02}));
        byte[] tbs = seq(
                version,
                tlv(0x02, serial.toByteArray()),
                sigAlg,
                name,
                seq(time(notBefore), time(notAfter)),
                name,
                pair.getPublic().getEncoded());

        Signature s = Signature.getInstance("SHA256withRSA");
        s.initSign(pair.getPrivate());
        s.update(tbs);
        byte[] sig = s.sign();
        byte[] bitString = new byte[sig.length + 1];
        System.arraycopy(sig, 0, bitString, 1, sig.length);
        return seq(tbs, sigAlg, tlv(0x03, bitString));
    }

    private static byte[] time(Date d) {
        Calendar cal = new Calendar(d);
        if (cal.year < 2050) return tlv(0x17, cal.format("yyMMddHHmmss'Z'"));
        return tlv(0x18, cal.format("yyyyMMddHHmmss'Z'"));
    }

    private static final class Calendar {
        final Date date;
        final int year;

        Calendar(Date date) {
            this.date = date;
            java.util.Calendar c = java.util.Calendar.getInstance(TimeZone.getTimeZone("UTC"), Locale.US);
            c.setTime(date);
            this.year = c.get(java.util.Calendar.YEAR);
        }

        byte[] format(String pattern) {
            SimpleDateFormat f = new SimpleDateFormat(pattern, Locale.US);
            f.setTimeZone(TimeZone.getTimeZone("UTC"));
            return f.format(date).getBytes(StandardCharsets.US_ASCII);
        }
    }

    private static byte[] oid(int... parts) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        o.write(parts[0] * 40 + parts[1]);
        for (int i = 2; i < parts.length; i++) {
            long v = parts[i];
            int n = 0;
            byte[] tmp = new byte[10];
            do {
                tmp[n++] = (byte) (v & 0x7f);
                v >>>= 7;
            } while (v != 0);
            for (int j = n - 1; j >= 0; j--) o.write(tmp[j] | (j > 0 ? 0x80 : 0));
        }
        return tlv(0x06, o.toByteArray());
    }

    private static byte[] seq(byte[]... items) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        for (byte[] item : items) o.write(item, 0, item.length);
        return tlv(0x30, o.toByteArray());
    }

    private static byte[] tlv(int tag, byte[] value) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        o.write(tag);
        int len = value.length;
        if (len < 0x80) {
            o.write(len);
        } else if (len < 0x100) {
            o.write(0x81);
            o.write(len);
        } else if (len < 0x10000) {
            o.write(0x82);
            o.write(len >>> 8);
            o.write(len & 0xff);
        } else {
            o.write(0x83);
            o.write(len >>> 16);
            o.write((len >>> 8) & 0xff);
            o.write(len & 0xff);
        }
        o.write(value, 0, value.length);
        return o.toByteArray();
    }
}
