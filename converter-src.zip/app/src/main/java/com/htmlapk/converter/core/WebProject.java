package com.htmlapk.converter.core;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** The web files that go inside the generated app, keyed by relative path. */
public final class WebProject {
    public final Map<String, byte[]> files;
    public final String entry;

    private WebProject(Map<String, byte[]> files, String entry) {
        this.files = files;
        this.entry = entry;
    }

    public static WebProject fromHtml(byte[] html) {
        Map<String, byte[]> files = new LinkedHashMap<>();
        files.put("index.html", html);
        return new WebProject(files, "index.html");
    }

    /** Reads a file that may be HTML or ZIP; ZIP is detected by its "PK" signature. */
    public static WebProject fromAny(byte[] data) throws IOException {
        if (data.length >= 4 && data[0] == 'P' && data[1] == 'K' && data[2] == 3 && data[3] == 4) {
            return fromZip(new ByteArrayInputStream(data));
        }
        return fromHtml(data);
    }

    public static WebProject fromZip(InputStream in) throws IOException {
        Map<String, byte[]> all = new TreeMap<>();
        try (ZipInputStream zip = new ZipInputStream(in)) {
            ZipEntry e;
            byte[] buf = new byte[16384];
            while ((e = zip.getNextEntry()) != null) {
                if (e.isDirectory()) continue;
                String name = clean(e.getName());
                if (name == null) continue;
                ByteArrayOutputStream o = new ByteArrayOutputStream();
                int n;
                while ((n = zip.read(buf)) != -1) o.write(buf, 0, n);
                all.put(name, o.toByteArray());
            }
        }
        if (all.isEmpty()) throw new IOException("The ZIP file is empty");

        String entryPath = pickEntry(all, true);
        if (entryPath == null) entryPath = pickEntry(all, false);
        if (entryPath == null) throw new IOException("No HTML file found in the ZIP");

        int slash = entryPath.lastIndexOf('/');
        String prefix = slash >= 0 ? entryPath.substring(0, slash + 1) : "";
        Map<String, byte[]> files = new LinkedHashMap<>();
        for (Map.Entry<String, byte[]> f : all.entrySet()) {
            if (f.getKey().startsWith(prefix)) files.put(f.getKey().substring(prefix.length()), f.getValue());
        }
        return new WebProject(files, entryPath.substring(prefix.length()));
    }

    /** Shallowest index.html (or, if none, shallowest .html/.htm file). */
    private static String pickEntry(Map<String, byte[]> all, boolean indexOnly) {
        String best = null;
        int bestDepth = Integer.MAX_VALUE;
        for (String path : all.keySet()) {
            String file = path.substring(path.lastIndexOf('/') + 1).toLowerCase(Locale.ROOT);
            boolean match = indexOnly
                    ? file.equals("index.html") || file.equals("index.htm")
                    : file.endsWith(".html") || file.endsWith(".htm");
            if (!match) continue;
            int depth = path.length() - path.replace("/", "").length();
            if (depth < bestDepth) {
                best = path;
                bestDepth = depth;
            }
        }
        return best;
    }

    /** Normalises a ZIP path; returns null for unsafe or junk entries. */
    private static String clean(String raw) {
        String name = raw.replace('\\', '/');
        while (name.startsWith("/")) name = name.substring(1);
        if (name.isEmpty() || name.startsWith("__MACOSX/")) return null;
        StringBuilder sb = new StringBuilder();
        for (String part : name.split("/")) {
            if (part.isEmpty() || part.equals(".")) continue;
            if (part.equals("..")) return null;
            if (sb.length() > 0) sb.append('/');
            sb.append(part);
        }
        String result = sb.toString();
        if (result.isEmpty() || result.endsWith(".DS_Store")) return null;
        return result;
    }
}
