package com.htmlapk.converter;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageInstaller;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.htmlapk.converter.core.ApkGenerator;
import com.htmlapk.converter.core.CertGen;
import com.htmlapk.converter.core.WebProject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Locale;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private static final int REQ_PROJECT = 1;
    private static final int REQ_ICON = 2;
    private static final int REQ_SAVE_APK = 3;
    private static final String ACTION_INSTALL_STATUS = "com.htmlapk.converter.INSTALL_STATUS";
    private static final Pattern PACKAGE = Pattern.compile("^[a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z][a-zA-Z0-9_]*)+$");
    private static final int[] COLORS = {0xFF1769AA, 0xFF0F766E, 0xFF7C3AED, 0xFFB91C1C, 0xFFC2410C, 0xFF15803D, 0xFF334155};

    private EditText nameField;
    private EditText packageField;
    private EditText versionNameField;
    private EditText versionCodeField;
    private CheckBox fullscreenBox;
    private TextView projectLabel;
    private ImageView iconPreview;
    private Button buildButton;
    private TextView statusText;
    private LinearLayout resultRow;

    private Uri projectUri;
    private String projectName;
    private byte[] customIconPng;
    private boolean autoPackage = true;
    private boolean settingPackage;
    private File lastApk;
    private boolean busy;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        refreshIconPreview();
    }

    // ------------------------------------------------------------------- UI

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(0xFFF1F5F9);
        scroll.setFitsSystemWindows(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(20), dp(18), dp(32));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("HTML to APK");
        title.setTextSize(26);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(0xFF0F172A);
        root.addView(title);
        TextView subtitle = text("Turn an HTML file or a ZIP of a website into an installable Android app.", 14, 0xFF475569);
        subtitle.setPadding(0, dp(4), 0, dp(12));
        root.addView(subtitle);

        LinearLayout card1 = card(root, "1. Your web project");
        projectLabel = text("No file chosen. Pick an .html file, or a .zip containing index.html with its CSS, JS and images.", 14, 0xFF334155);
        card1.addView(projectLabel);
        Button pickProject = button("Choose HTML or ZIP", false);
        pickProject.setOnClickListener(v -> pick(REQ_PROJECT, "*/*"));
        card1.addView(pickProject, matchWrap(dp(10)));

        LinearLayout card2 = card(root, "2. App details");
        nameField = field(card2, "App name", "My App", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        packageField = field(card2, "Package name (unique ID)", "com.htmlapk.myapp", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        versionNameField = field(card2, "Version name", "1.0", InputType.TYPE_CLASS_TEXT);
        versionCodeField = field(card2, "Version code (raise it for each update)", "1", InputType.TYPE_CLASS_NUMBER);
        versionNameField.setText("1.0");
        versionCodeField.setText("1");
        fullscreenBox = new CheckBox(this);
        fullscreenBox.setText("Full-screen (hide status and navigation bars)");
        fullscreenBox.setTextColor(0xFF334155);
        card2.addView(fullscreenBox, matchWrap(dp(10)));

        nameField.addTextChangedListener(new SimpleWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                if (autoPackage) {
                    settingPackage = true;
                    packageField.setText(suggestPackage(s.toString()));
                    settingPackage = false;
                }
                if (customIconPng == null) refreshIconPreview();
            }
        });
        packageField.addTextChangedListener(new SimpleWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                if (!settingPackage) autoPackage = false;
            }
        });

        LinearLayout card3 = card(root, "3. Icon (optional)");
        LinearLayout iconRow = new LinearLayout(this);
        iconRow.setOrientation(LinearLayout.HORIZONTAL);
        iconRow.setGravity(Gravity.CENTER_VERTICAL);
        iconPreview = new ImageView(this);
        iconRow.addView(iconPreview, new LinearLayout.LayoutParams(dp(64), dp(64)));
        LinearLayout iconButtons = new LinearLayout(this);
        iconButtons.setOrientation(LinearLayout.VERTICAL);
        Button pickIcon = button("Choose image", false);
        pickIcon.setOnClickListener(v -> pick(REQ_ICON, "image/*"));
        Button resetIcon = button("Use letter icon", false);
        resetIcon.setOnClickListener(v -> {
            customIconPng = null;
            refreshIconPreview();
        });
        iconButtons.addView(pickIcon, matchWrap(0));
        iconButtons.addView(resetIcon, matchWrap(dp(4)));
        LinearLayout.LayoutParams ibp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        ibp.leftMargin = dp(14);
        iconRow.addView(iconButtons, ibp);
        card3.addView(iconRow);

        buildButton = button("Build APK", true);
        buildButton.setOnClickListener(v -> startBuild());
        root.addView(buildButton, matchWrap(dp(18)));

        statusText = text("", 14, 0xFF334155);
        statusText.setPadding(0, dp(12), 0, 0);
        root.addView(statusText);

        resultRow = new LinearLayout(this);
        resultRow.setOrientation(LinearLayout.HORIZONTAL);
        resultRow.setVisibility(View.GONE);
        Button install = button("Install", true);
        install.setOnClickListener(v -> installApk());
        Button save = button("Save APK", false);
        save.setOnClickListener(v -> saveApk());
        LinearLayout.LayoutParams half = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        LinearLayout.LayoutParams half2 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        half2.leftMargin = dp(10);
        resultRow.addView(install, half);
        resultRow.addView(save, half2);
        root.addView(resultRow, matchWrap(dp(12)));

        TextView note = text("Generated apps are signed with a key stored inside this converter. "
                + "To update an app later, build it again with the same package name and a higher version code. "
                + "If you uninstall this converter, the key is lost and old apps must be uninstalled before updating.", 12, 0xFF64748B);
        note.setPadding(0, dp(20), 0, 0);
        root.addView(note);

        setContentView(scroll);
    }

    private LinearLayout card(LinearLayout parent, String heading) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(16));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setCornerRadius(dp(16));
        card.setBackground(bg);
        TextView h = text(heading, 17, 0xFF0F172A);
        h.setTypeface(Typeface.DEFAULT_BOLD);
        h.setPadding(0, 0, 0, dp(8));
        card.addView(h);
        parent.addView(card, matchWrap(dp(12)));
        return card;
    }

    private EditText field(LinearLayout parent, String label, String hint, int inputType) {
        TextView l = text(label, 13, 0xFF475569);
        l.setPadding(0, dp(8), 0, dp(2));
        parent.addView(l);
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setInputType(inputType);
        e.setTextColor(0xFF0F172A);
        parent.addView(e, matchWrap(0));
        return e;
    }

    private TextView text(String s, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private Button button(String label, boolean primary) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(15);
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(12));
        if (primary) {
            bg.setColor(0xFF0F172A);
            b.setTextColor(Color.WHITE);
        } else {
            bg.setColor(0xFFE2E8F0);
            b.setTextColor(0xFF0F172A);
        }
        b.setBackground(bg);
        b.setMinHeight(dp(48));
        return b;
    }

    private LinearLayout.LayoutParams matchWrap(int topMargin) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = topMargin;
        return p;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private abstract static class SimpleWatcher implements TextWatcher {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }
    }

    // --------------------------------------------------------------- picking

    private void pick(int request, String type) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(type);
        try {
            startActivityForResult(intent, request);
        } catch (ActivityNotFoundException e) {
            status("No file picker found on this phone.");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == REQ_PROJECT) {
            projectUri = uri;
            projectName = displayName(uri);
            projectLabel.setText("Selected: " + projectName);
            if (nameField.getText().toString().trim().isEmpty()) {
                String base = projectName.replaceAll("\\.[^.]*$", "").replaceAll("[_\\-]+", " ").trim();
                if (!base.isEmpty() && !base.equalsIgnoreCase("index")) nameField.setText(capitalize(base));
            }
        } else if (requestCode == REQ_ICON) {
            try {
                customIconPng = loadIcon(uri);
                refreshIconPreview();
            } catch (Exception e) {
                status("Could not read that image: " + e.getMessage());
            }
        } else if (requestCode == REQ_SAVE_APK && lastApk != null) {
            try (InputStream in = new FileInputStream(lastApk);
                 OutputStream out = getContentResolver().openOutputStream(uri)) {
                if (out == null) throw new IOException("Cannot open destination");
                copy(in, out);
                status("APK saved.");
            } catch (IOException e) {
                status("Save failed: " + e.getMessage());
            }
        }
    }

    private String displayName(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                String n = c.getString(0);
                if (n != null && !n.isEmpty()) return n;
            }
        } catch (Exception ignored) {
        }
        String last = uri.getLastPathSegment();
        return last == null ? "project" : last;
    }

    // ----------------------------------------------------------------- icons

    private void refreshIconPreview() {
        byte[] png = customIconPng != null ? customIconPng : letterIcon(currentName());
        iconPreview.setImageBitmap(BitmapFactory.decodeByteArray(png, 0, png.length));
    }

    private byte[] loadIcon(Uri uri) throws IOException {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            BitmapFactory.decodeStream(in, null, bounds);
        }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw new IOException("not an image");
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = 1;
        while (Math.min(bounds.outWidth, bounds.outHeight) / (opts.inSampleSize * 2) >= 384) opts.inSampleSize *= 2;
        Bitmap src;
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            src = BitmapFactory.decodeStream(in, null, opts);
        }
        if (src == null) throw new IOException("not an image");
        int size = Math.min(src.getWidth(), src.getHeight());
        Rect from = new Rect((src.getWidth() - size) / 2, (src.getHeight() - size) / 2,
                (src.getWidth() + size) / 2, (src.getHeight() + size) / 2);
        Bitmap out = Bitmap.createBitmap(192, 192, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(out);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        canvas.drawBitmap(src, from, new Rect(0, 0, 192, 192), p);
        return toPng(out);
    }

    private byte[] letterIcon(String name) {
        String clean = name.trim();
        String letter = clean.isEmpty() ? "A" : clean.substring(0, clean.offsetByCodePoints(0, 1)).toUpperCase(Locale.ROOT);
        int color = COLORS[Math.abs(clean.hashCode() % COLORS.length)];
        Bitmap bmp = Bitmap.createBitmap(192, 192, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
        bg.setColor(color);
        c.drawRoundRect(new RectF(0, 0, 192, 192), 42, 42, bg);
        Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
        t.setColor(Color.WHITE);
        t.setTextSize(104);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextAlign(Paint.Align.CENTER);
        Rect r = new Rect();
        t.getTextBounds(letter, 0, letter.length(), r);
        c.drawText(letter, 96, 96 + r.height() / 2f - r.bottom, t);
        return toPng(bmp);
    }

    private static byte[] toPng(Bitmap bmp) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.PNG, 100, o);
        return o.toByteArray();
    }

    // ----------------------------------------------------------------- build

    private String currentName() {
        return nameField == null ? "" : nameField.getText().toString().trim();
    }

    private void startBuild() {
        if (busy) return;
        final String name = currentName();
        final String pkg = packageField.getText().toString().trim();
        final String versionName = versionNameField.getText().toString().trim();
        int code;
        try {
            code = Integer.parseInt(versionCodeField.getText().toString().trim());
        } catch (NumberFormatException e) {
            code = -1;
        }
        if (projectUri == null) {
            status("Choose an HTML or ZIP file first.");
            return;
        }
        if (name.isEmpty()) {
            status("Enter an app name.");
            return;
        }
        if (!PACKAGE.matcher(pkg).matches()) {
            status("Package name must look like com.example.myapp (letters, digits, underscores, at least one dot).");
            return;
        }
        if (pkg.equals(getPackageName())) {
            status("That package name belongs to this converter. Choose another.");
            return;
        }
        if (versionName.isEmpty()) {
            status("Enter a version name, e.g. 1.0");
            return;
        }
        if (code < 1) {
            status("Version code must be a whole number, 1 or higher.");
            return;
        }

        final ApkGenerator.Options opt = new ApkGenerator.Options();
        opt.appName = name;
        opt.packageName = pkg;
        opt.versionName = versionName;
        opt.versionCode = code;
        opt.fullscreen = fullscreenBox.isChecked();
        opt.iconPng = customIconPng != null ? customIconPng : letterIcon(name);
        final Uri source = projectUri;

        busy = true;
        buildButton.setEnabled(false);
        resultRow.setVisibility(View.GONE);
        status("Building " + name + "…");

        new Thread(() -> {
            try {
                byte[] data;
                try (InputStream in = getContentResolver().openInputStream(source)) {
                    if (in == null) throw new IOException("Cannot open the selected file");
                    ByteArrayOutputStream o = new ByteArrayOutputStream();
                    copy(in, o);
                    data = o.toByteArray();
                }
                WebProject project = WebProject.fromAny(data);

                File template = new File(getCacheDir(), "template.apk");
                try (InputStream in = getAssets().open("template.apk");
                     OutputStream out = new FileOutputStream(template)) {
                    copy(in, out);
                }
                CertGen.SigningKey key = CertGen.loadOrCreate(new File(getFilesDir(), "signing"));
                File outDir = new File(getCacheDir(), "output");
                deleteTree(outDir);
                if (!outDir.mkdirs()) throw new IOException("Cannot create output folder");
                File out = new File(outDir, safeFileName(name) + ".apk");
                ApkGenerator.generate(template, project, opt, key, out, new File(getCacheDir(), "work"));

                runOnUiThread(() -> {
                    lastApk = out;
                    busy = false;
                    buildButton.setEnabled(true);
                    resultRow.setVisibility(View.VISIBLE);
                    status("Done: " + out.getName() + " (" + (out.length() / 1024) + " KB, "
                            + project.files.size() + " web files, opens " + project.entry + ").");
                });
            } catch (Throwable e) {
                String msg = e.getClass().getSimpleName() + (e.getMessage() != null ? ": " + e.getMessage() : "");
                runOnUiThread(() -> {
                    busy = false;
                    buildButton.setEnabled(true);
                    status("Build failed. " + msg);
                });
            }
        }).start();
    }

    // --------------------------------------------------------------- install

    private void installApk() {
        if (lastApk == null || !lastApk.isFile()) {
            status("Build the APK first.");
            return;
        }
        if (!getPackageManager().canRequestPackageInstalls()) {
            status("Allow \"Install unknown apps\" for HTML to APK, then come back and tap Install again.");
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        Uri.parse("package:" + getPackageName())));
            } catch (ActivityNotFoundException ignored) {
            }
            return;
        }
        status("Installing…");
        final File apk = lastApk;
        new Thread(() -> {
            try {
                PackageInstaller installer = getPackageManager().getPackageInstaller();
                PackageInstaller.SessionParams params =
                        new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
                int sessionId = installer.createSession(params);
                try (PackageInstaller.Session session = installer.openSession(sessionId)) {
                    try (InputStream in = new FileInputStream(apk);
                         OutputStream out = session.openWrite("base.apk", 0, apk.length())) {
                        copy(in, out);
                        session.fsync(out);
                    }
                    Intent callback = new Intent(this, MainActivity.class)
                            .setAction(ACTION_INSTALL_STATUS)
                            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    int flags = PendingIntent.FLAG_UPDATE_CURRENT;
                    if (Build.VERSION.SDK_INT >= 31) flags |= PendingIntent.FLAG_MUTABLE;
                    PendingIntent pending = PendingIntent.getActivity(this, sessionId, callback, flags);
                    session.commit(pending.getIntentSender());
                }
            } catch (Exception e) {
                runOnUiThread(() -> status("Install failed: " + e.getMessage()
                        + ". Use Save APK and open the file instead."));
            }
        }).start();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (!ACTION_INSTALL_STATUS.equals(intent.getAction())) return;
        int result = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE);
        if (result == PackageInstaller.STATUS_PENDING_USER_ACTION) {
            Intent confirm = intent.getParcelableExtra(Intent.EXTRA_INTENT);
            if (confirm != null) {
                try {
                    startActivity(confirm);
                } catch (ActivityNotFoundException e) {
                    status("Install failed: no installer found.");
                }
            }
        } else if (result == PackageInstaller.STATUS_SUCCESS) {
            status("Installed! Find the app on your home screen or app drawer.");
        } else {
            String message = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE);
            String hint = result == PackageInstaller.STATUS_FAILURE_CONFLICT
                    ? " An app with this package name but a different signature is installed; uninstall it first."
                    : "";
            status("Install did not finish (" + (message == null ? "cancelled" : message) + ")." + hint);
        }
    }

    private void saveApk() {
        if (lastApk == null) return;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/vnd.android.package-archive");
        intent.putExtra(Intent.EXTRA_TITLE, lastApk.getName());
        try {
            startActivityForResult(intent, REQ_SAVE_APK);
        } catch (ActivityNotFoundException e) {
            status("Cannot save files on this phone.");
        }
    }

    // --------------------------------------------------------------- helpers

    private void status(String s) {
        statusText.setText(s);
    }

    private static String suggestPackage(String name) {
        String clean = name.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
        if (clean.isEmpty()) clean = "myapp";
        if (Character.isDigit(clean.charAt(0))) clean = "app" + clean;
        return "com.htmlapk." + clean;
    }

    private static String safeFileName(String name) {
        String s = name.replaceAll("[^A-Za-z0-9 _.-]", "").trim().replace(' ', '-');
        return s.isEmpty() ? "app" : s;
    }

    private static String capitalize(String s) {
        return s.isEmpty() ? s : Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    private static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] buf = new byte[65536];
        int n;
        while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
    }

    private static void deleteTree(File f) {
        File[] children = f.listFiles();
        if (children != null) for (File c : children) deleteTree(c);
        //noinspection ResultOfMethodCallIgnored
        f.delete();
    }
}
