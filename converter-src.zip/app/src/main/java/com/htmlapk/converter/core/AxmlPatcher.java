package com.htmlapk.converter.core;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Reads and patches a compiled (binary) AndroidManifest.xml.
 * New string values are appended to the string pool, so they can be any length.
 */
public final class AxmlPatcher {
    private static final int RES_XML_TYPE = 0x0003;
    private static final int RES_STRING_POOL_TYPE = 0x0001;
    private static final int RES_XML_RESOURCE_MAP_TYPE = 0x0180;
    private static final int RES_XML_START_ELEMENT_TYPE = 0x0102;

    private static final int ATTR_LABEL = 0x01010001;
    private static final int ATTR_VERSION_CODE = 0x0101021b;
    private static final int ATTR_VERSION_NAME = 0x0101021c;

    private static final int TYPE_STRING = 0x03;
    private static final int TYPE_INT_DEC = 0x10;

    private static final int SORTED_FLAG = 1;
    private static final int UTF8_FLAG = 1 << 8;

    private AxmlPatcher() {
    }

    /** Values found in a manifest; used for checks and tests. */
    public static Map<String, String> readInfo(byte[] axml) throws IOException {
        Parsed p = parse(axml);
        Map<String, String> info = new LinkedHashMap<>();
        ByteBuffer b = ByteBuffer.wrap(axml).order(ByteOrder.LITTLE_ENDIAN);
        for (int[] chunk : p.chunks) {
            if (chunk[1] != RES_XML_START_ELEMENT_TYPE) continue;
            int pos = chunk[0];
            int ext = pos + u16(b, pos + 2);
            String element = p.string(b.getInt(ext + 4));
            int attrStart = u16(b, ext + 8);
            int attrSize = u16(b, ext + 10);
            int attrCount = u16(b, ext + 12);
            for (int i = 0; i < attrCount; i++) {
                int a = ext + attrStart + i * attrSize;
                int nameIdx = b.getInt(a + 4);
                String name = p.string(nameIdx);
                int type = b.get(a + 15) & 0xff;
                int data = b.getInt(a + 16);
                String value;
                if (type == TYPE_STRING) value = p.string(data);
                else value = String.valueOf(data);
                info.put(element + "@" + name, value);
            }
        }
        return info;
    }

    public static byte[] patch(byte[] axml, String packageName, String label,
                               String versionName, int versionCode) throws IOException {
        Parsed p = parse(axml);
        List<String> strings = new ArrayList<>(p.strings);
        byte[] out = axml.clone();
        ByteBuffer b = ByteBuffer.wrap(out).order(ByteOrder.LITTLE_ENDIAN);

        int pkgIdx = strings.size();
        strings.add(packageName);
        int labelIdx = strings.size();
        strings.add(label);
        int verIdx = strings.size();
        strings.add(versionName);

        boolean pkgDone = false;
        boolean labelDone = false;
        for (int[] chunk : p.chunks) {
            if (chunk[1] != RES_XML_START_ELEMENT_TYPE) continue;
            int pos = chunk[0];
            int ext = pos + u16(b, pos + 2);
            String element = p.string(b.getInt(ext + 4));
            int attrStart = u16(b, ext + 8);
            int attrSize = u16(b, ext + 10);
            int attrCount = u16(b, ext + 12);
            for (int i = 0; i < attrCount; i++) {
                int a = ext + attrStart + i * attrSize;
                int nameIdx = b.getInt(a + 4);
                String name = p.string(nameIdx);
                int resId = (nameIdx >= 0 && nameIdx < p.resMap.length) ? p.resMap[nameIdx] : 0;
                if ("manifest".equals(element)) {
                    if (resId == 0 && "package".equals(name)) {
                        setString(b, a, pkgIdx);
                        pkgDone = true;
                    } else if (resId == ATTR_VERSION_CODE || (resId == 0 && "versionCode".equals(name))) {
                        b.putInt(a + 8, -1);
                        b.putShort(a + 12, (short) 8);
                        b.put(a + 14, (byte) 0);
                        b.put(a + 15, (byte) TYPE_INT_DEC);
                        b.putInt(a + 16, versionCode);
                    } else if (resId == ATTR_VERSION_NAME || (resId == 0 && "versionName".equals(name))) {
                        setString(b, a, verIdx);
                    }
                } else if ("application".equals(element)) {
                    if (resId == ATTR_LABEL || (resId == 0 && "label".equals(name))) {
                        setString(b, a, labelIdx);
                        labelDone = true;
                    }
                }
            }
        }
        if (!pkgDone) throw new IOException("Template manifest has no package attribute");
        if (!labelDone) throw new IOException("Template manifest has no application label");

        byte[] newPool = buildPool(strings, p);
        ByteArrayOutputStream result = new ByteArrayOutputStream(out.length + newPool.length);
        result.write(out, 0, p.headerSize);
        for (int[] chunk : p.chunks) {
            if (chunk[0] == p.poolStart) result.write(newPool, 0, newPool.length);
            else result.write(out, chunk[0], chunk[2]);
        }
        byte[] finalBytes = result.toByteArray();
        ByteBuffer.wrap(finalBytes).order(ByteOrder.LITTLE_ENDIAN).putInt(4, finalBytes.length);
        return finalBytes;
    }

    private static void setString(ByteBuffer b, int a, int idx) {
        b.putInt(a + 8, idx);
        b.putShort(a + 12, (short) 8);
        b.put(a + 14, (byte) 0);
        b.put(a + 15, (byte) TYPE_STRING);
        b.putInt(a + 16, idx);
    }

    // ---------------------------------------------------------------- parsing

    private static final class Parsed {
        int headerSize;
        List<int[]> chunks = new ArrayList<>(); // {start, type, size}
        int poolStart = -1;
        int poolFlags;
        List<String> strings = new ArrayList<>();
        int[] styleOffsets = new int[0];
        byte[] styleData = new byte[0];
        int[] resMap = new int[0];

        String string(int idx) {
            if (idx < 0 || idx >= strings.size()) return null;
            return strings.get(idx);
        }
    }

    private static Parsed parse(byte[] axml) throws IOException {
        if (axml.length < 8) throw new IOException("Manifest too small");
        ByteBuffer b = ByteBuffer.wrap(axml).order(ByteOrder.LITTLE_ENDIAN);
        if (u16(b, 0) != RES_XML_TYPE) throw new IOException("Manifest is not binary XML");
        Parsed p = new Parsed();
        p.headerSize = u16(b, 2);
        int total = Math.min(b.getInt(4), axml.length);
        int pos = p.headerSize;
        while (pos + 8 <= total) {
            int type = u16(b, pos);
            int size = b.getInt(pos + 4);
            if (size < 8 || pos + size > total) throw new IOException("Bad chunk in manifest");
            p.chunks.add(new int[]{pos, type, size});
            if (type == RES_STRING_POOL_TYPE && p.poolStart < 0) {
                p.poolStart = pos;
                readPool(b, pos, p);
            } else if (type == RES_XML_RESOURCE_MAP_TYPE) {
                int hs = u16(b, pos + 2);
                int n = (size - hs) / 4;
                p.resMap = new int[n];
                for (int i = 0; i < n; i++) p.resMap[i] = b.getInt(pos + hs + i * 4);
            }
            pos += size;
        }
        if (p.poolStart < 0) throw new IOException("Manifest has no string pool");
        return p;
    }

    private static void readPool(ByteBuffer b, int sp, Parsed p) throws IOException {
        int hs = u16(b, sp + 2);
        int size = b.getInt(sp + 4);
        int count = b.getInt(sp + 8);
        int styleCount = b.getInt(sp + 12);
        int flags = b.getInt(sp + 16);
        int stringsStart = b.getInt(sp + 20);
        int stylesStart = b.getInt(sp + 24);
        p.poolFlags = flags;
        boolean utf8 = (flags & UTF8_FLAG) != 0;
        for (int i = 0; i < count; i++) {
            int off = sp + stringsStart + b.getInt(sp + hs + i * 4);
            p.strings.add(utf8 ? readUtf8(b, off) : readUtf16(b, off));
        }
        p.styleOffsets = new int[styleCount];
        for (int i = 0; i < styleCount; i++) {
            p.styleOffsets[i] = b.getInt(sp + hs + count * 4 + i * 4);
        }
        if (styleCount > 0 && stylesStart > 0 && stylesStart < size) {
            p.styleData = new byte[size - stylesStart];
            for (int i = 0; i < p.styleData.length; i++) p.styleData[i] = b.get(sp + stylesStart + i);
        }
    }

    private static String readUtf16(ByteBuffer b, int off) {
        int len = u16(b, off);
        off += 2;
        if ((len & 0x8000) != 0) {
            len = ((len & 0x7fff) << 16) | u16(b, off);
            off += 2;
        }
        char[] c = new char[len];
        for (int i = 0; i < len; i++) c[i] = (char) u16(b, off + i * 2);
        return new String(c);
    }

    private static String readUtf8(ByteBuffer b, int off) {
        int first = b.get(off) & 0xff;
        off += (first & 0x80) != 0 ? 2 : 1;
        int len = b.get(off) & 0xff;
        if ((len & 0x80) != 0) {
            len = ((len & 0x7f) << 8) | (b.get(off + 1) & 0xff);
            off += 2;
        } else {
            off += 1;
        }
        byte[] bytes = new byte[len];
        for (int i = 0; i < len; i++) bytes[i] = b.get(off + i);
        return new String(bytes, StandardCharsets.UTF_8);
    }

    // --------------------------------------------------------------- building

    private static byte[] buildPool(List<String> strings, Parsed p) throws IOException {
        boolean utf8 = (p.poolFlags & UTF8_FLAG) != 0;
        ByteArrayOutputStream data = new ByteArrayOutputStream();
        int[] offsets = new int[strings.size()];
        for (int i = 0; i < strings.size(); i++) {
            offsets[i] = data.size();
            String s = strings.get(i) == null ? "" : strings.get(i);
            if (utf8) writeUtf8(data, s);
            else writeUtf16(data, s);
        }
        while (data.size() % 4 != 0) data.write(0);

        int headerSize = 28;
        int styleCount = p.styleOffsets.length;
        int stringsStart = headerSize + 4 * strings.size() + 4 * styleCount;
        int stylesStart = styleCount > 0 ? stringsStart + data.size() : 0;
        int size = stringsStart + data.size() + (styleCount > 0 ? p.styleData.length : 0);
        while (size % 4 != 0) size++;

        ByteBuffer out = ByteBuffer.allocate(size).order(ByteOrder.LITTLE_ENDIAN);
        out.putShort((short) RES_STRING_POOL_TYPE);
        out.putShort((short) headerSize);
        out.putInt(size);
        out.putInt(strings.size());
        out.putInt(styleCount);
        out.putInt(p.poolFlags & ~SORTED_FLAG);
        out.putInt(stringsStart);
        out.putInt(stylesStart);
        for (int o : offsets) out.putInt(o);
        for (int o : p.styleOffsets) out.putInt(o);
        out.put(data.toByteArray());
        if (styleCount > 0) out.put(p.styleData);
        return out.array();
    }

    private static void writeUtf16(ByteArrayOutputStream o, String s) throws IOException {
        int len = s.length();
        if (len > 0x7fff) {
            writeU16(o, 0x8000 | (len >>> 16));
            writeU16(o, len & 0xffff);
        } else {
            writeU16(o, len);
        }
        for (int i = 0; i < len; i++) writeU16(o, s.charAt(i));
        writeU16(o, 0);
    }

    private static void writeUtf8(ByteArrayOutputStream o, String s) throws IOException {
        byte[] bytes = s.getBytes(StandardCharsets.UTF_8);
        if (s.length() > 0x7fff || bytes.length > 0x7fff) throw new IOException("String too long");
        writeLen8(o, s.length());
        writeLen8(o, bytes.length);
        o.write(bytes);
        o.write(0);
    }

    private static void writeLen8(ByteArrayOutputStream o, int len) {
        if (len > 0x7f) {
            o.write(0x80 | (len >>> 8));
            o.write(len & 0xff);
        } else {
            o.write(len);
        }
    }

    private static void writeU16(ByteArrayOutputStream o, int v) {
        o.write(v & 0xff);
        o.write((v >>> 8) & 0xff);
    }

    private static int u16(ByteBuffer b, int off) {
        return b.getShort(off) & 0xffff;
    }
}
