package com.htmlapk.converter.core;

import com.android.apksig.ApkSigner;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

/**
 * Builds a new app from the template APK: swaps in the web files, app name,
 * package name, version and icon, then aligns and signs the result.
 */
public final class ApkGenerator {
    public static final class Options {
        public String appName;
        public String packageName;
        public String versionName = "1.0";
        public int versionCode = 1;
        public boolean fullscreen;
        /** PNG bytes for the launcher icon, or null to keep the template icon. */
        public byte[] iconPng;
    }

    private static final String ICON_NAME = "/htmlapk_icon.png";
    private static final long FIXED_TIME = 1577836800000L; // 2020-01-01

    private ApkGenerator() {
    }

    public static void generate(File templateApk, WebProject project, Options opt,
                                CertGen.SigningKey key, File outApk, File workDir) throws Exception {
        if (!workDir.isDirectory() && !workDir.mkdirs()) throw new IOException("Cannot create " + workDir);
        File unsigned = new File(workDir, "unsigned.apk");
        try {
            writeUnsigned(templateApk, project, opt, unsigned);
        } catch (IOException e) {
            throw new IOException("Preparing the APK failed: " + e.getMessage(), e);
        }

        if (outApk.exists() && !outApk.delete()) throw new IOException("Cannot replace " + outApk);
        ApkSigner.SignerConfig signerConfig = new ApkSigner.SignerConfig.Builder(
                "CERT", key.privateKey, Collections.singletonList(key.certificate)).build();
        ApkSigner signer = new ApkSigner.Builder(Collections.singletonList(signerConfig))
                .setInputApk(unsigned)
                .setOutputApk(outApk)
                .setV1SigningEnabled(true)
                .setV2SigningEnabled(true)
                .setV3SigningEnabled(true)
                .setCreatedBy("HTML to APK Converter")
                .build();
        try {
            signer.sign();
        } catch (Exception e) {
            throw new IOException("Signing failed: " + e, e);
        }
        //noinspection ResultOfMethodCallIgnored
        unsigned.delete();
    }

    static void writeUnsigned(File templateApk, WebProject project, Options opt, File out) throws IOException {
        int iconsReplaced = 0;
        StringBuilder pngs = new StringBuilder();
        boolean manifestDone = false;
        try (ZipFile template = new ZipFile(templateApk);
             CountingStream counter = new CountingStream(new BufferedOutputStream(new FileOutputStream(out)));
             ZipOutputStream zip = new ZipOutputStream(counter)) {
            Enumeration<? extends ZipEntry> entries = template.entries();
            while (entries.hasMoreElements()) {
                ZipEntry e = entries.nextElement();
                String name = e.getName();
                if (e.isDirectory() || isSignatureFile(name)) continue;
                if (name.startsWith("assets/www/") || name.equals("assets/htmlapk.properties")) continue;
                byte[] data;
                try (InputStream in = template.getInputStream(e)) {
                    data = readAll(in);
                }
                if (name.endsWith(".png") && pngs.length() < 300) pngs.append(name).append(' ');
                if (name.equals("AndroidManifest.xml")) {
                    try {
                        data = AxmlPatcher.patch(data, opt.packageName, opt.appName, opt.versionName, opt.versionCode);
                    } catch (IOException | RuntimeException ex) {
                        throw new IOException("Manifest update failed: " + ex, ex);
                    }
                    manifestDone = true;
                } else if (opt.iconPng != null && name.startsWith("res/") && name.endsWith(ICON_NAME)) {
                    data = opt.iconPng;
                    iconsReplaced++;
                }
                boolean store = e.getMethod() == ZipEntry.STORED || name.equals("resources.arsc");
                put(zip, counter, name, data, store);
            }
            if (!manifestDone) throw new IOException("Template has no AndroidManifest.xml");
            if (opt.iconPng != null && iconsReplaced == 0) throw new IOException("Template icon not found. PNG files: " + pngs);

            put(zip, counter, "assets/htmlapk.properties", config(project, opt), false);
            for (Map.Entry<String, byte[]> f : project.files.entrySet()) {
                put(zip, counter, "assets/www/" + f.getKey(), f.getValue(), false);
            }
        }
    }

    private static byte[] config(WebProject project, Options opt) throws IOException {
        Properties p = new Properties();
        p.setProperty("entry", project.entry);
        p.setProperty("fullscreen", String.valueOf(opt.fullscreen));
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        p.store(o, null);
        return o.toByteArray();
    }

    /** Writes one entry; stored entries get padding so their data starts on a 4-byte boundary. */
    private static void put(ZipOutputStream zip, CountingStream counter, String name, byte[] data,
                            boolean store) throws IOException {
        ZipEntry e = new ZipEntry(name);
        e.setTime(FIXED_TIME);
        if (store) {
            CRC32 crc = new CRC32();
            crc.update(data);
            e.setMethod(ZipEntry.STORED);
            e.setSize(data.length);
            e.setCompressedSize(data.length);
            e.setCrc(crc.getValue());
            long headerEnd = counter.count + 30 + name.getBytes(StandardCharsets.UTF_8).length;
            int pad = (int) ((4 - (headerEnd % 4)) % 4);
            if (pad != 0) {
                // Extra field 0xD935 (Android alignment) with `pad` bytes of data: total 4 + pad.
                byte[] extra = new byte[4 + pad];
                extra[0] = (byte) 0x35;
                extra[1] = (byte) 0xD9;
                extra[2] = (byte) pad;
                extra[3] = 0;
                e.setExtra(extra);
            }
        } else {
            e.setMethod(ZipEntry.DEFLATED);
        }
        zip.putNextEntry(e);
        zip.write(data);
        zip.closeEntry();
    }

    private static boolean isSignatureFile(String name) {
        if (!name.startsWith("META-INF/")) return false;
        String upper = name.toUpperCase(Locale.ROOT);
        return upper.equals("META-INF/MANIFEST.MF") || upper.endsWith(".SF") || upper.endsWith(".RSA")
                || upper.endsWith(".DSA") || upper.endsWith(".EC");
    }

    static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) != -1) o.write(buf, 0, n);
        return o.toByteArray();
    }

    private static final class CountingStream extends FilterOutputStream {
        long count;

        CountingStream(OutputStream out) {
            super(out);
        }

        @Override
        public void write(int b) throws IOException {
            out.write(b);
            count++;
        }

        @Override
        public void write(byte[] b, int off, int len) throws IOException {
            out.write(b, off, len);
            count += len;
        }
    }
}
