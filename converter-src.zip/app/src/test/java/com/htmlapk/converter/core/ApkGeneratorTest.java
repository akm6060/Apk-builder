package com.htmlapk.converter.core;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

import javax.imageio.ImageIO;

/** Builds a sample app from the real template; the CI workflow then verifies it with apksigner and aapt2. */
public class ApkGeneratorTest {
    @Test
    public void generatesSampleApp() throws Exception {
        File template = new File("src/main/assets/template.apk");
        assertTrue("template.apk missing: " + template.getAbsolutePath(), template.isFile());

        ByteArrayOutputStream zipBytes = new ByteArrayOutputStream();
        try (ZipOutputStream zip = new ZipOutputStream(zipBytes)) {
            add(zip, "my-site/index.html", "<!doctype html><html><head><meta charset=\"utf-8\">"
                    + "<link rel=\"stylesheet\" href=\"css/style.css\"></head><body><h1>Sample app ✓</h1>"
                    + "<script src=\"js/app.js\"></script></body></html>");
            add(zip, "my-site/css/style.css", "body{font-family:sans-serif;background:#eef}");
            add(zip, "my-site/js/app.js", "document.body.insertAdjacentHTML('beforeend','<p>JS works</p>');");
        }
        WebProject project = WebProject.fromAny(zipBytes.toByteArray());
        assertEquals("index.html", project.entry);
        assertEquals(3, project.files.size());

        BufferedImage img = new BufferedImage(192, 192, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        g.setColor(new Color(0x15803D));
        g.fillRect(0, 0, 192, 192);
        g.dispose();
        ByteArrayOutputStream png = new ByteArrayOutputStream();
        ImageIO.write(img, "png", png);

        ApkGenerator.Options opt = new ApkGenerator.Options();
        opt.appName = "Sample HTML App";
        opt.packageName = "com.htmlapk.sample";
        opt.versionName = "2.5";
        opt.versionCode = 7;
        opt.fullscreen = false;
        opt.iconPng = png.toByteArray();

        CertGen.SigningKey key = CertGen.loadOrCreate(new File("build/test-signing"));
        File out = new File("build/test-output/sample-app.apk");
        assertTrue(out.getParentFile().isDirectory() || out.getParentFile().mkdirs());
        ApkGenerator.generate(template, project, opt, key, out, new File("build/test-work"));
        assertTrue(out.length() > 0);

        try (ZipFile apk = new ZipFile(out)) {
            ZipEntry manifest = apk.getEntry("AndroidManifest.xml");
            assertNotNull(manifest);
            Map<String, String> info = AxmlPatcher.readInfo(ApkGenerator.readAll(apk.getInputStream(manifest)));
            System.out.println("Patched manifest: " + info);
            assertEquals("com.htmlapk.sample", info.get("manifest@package"));
            assertEquals("Sample HTML App", info.get("application@label"));
            assertEquals("2.5", info.get("manifest@versionName"));
            assertEquals("7", info.get("manifest@versionCode"));
            assertNotNull(apk.getEntry("assets/www/index.html"));
            assertNotNull(apk.getEntry("assets/www/css/style.css"));
            assertNotNull(apk.getEntry("assets/htmlapk.properties"));
        }
    }

    private static void add(ZipOutputStream zip, String name, String text) throws Exception {
        zip.putNextEntry(new ZipEntry(name));
        zip.write(text.getBytes(StandardCharsets.UTF_8));
        zip.closeEntry();
    }
}
