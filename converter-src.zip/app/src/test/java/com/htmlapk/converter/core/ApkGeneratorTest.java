package com.htmlapk.converter.core;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.zip.CRC32;
import java.util.zip.Deflater;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

/** Builds a sample app from the real template; the CI workflow then verifies it with apksigner and aapt2. */
public class ApkGeneratorTest {
    @Test
    public void generatesSampleApp() throws Exception {
        File template = new File("src/main/assets/template.apk");
        assertTrue("template.apk missing: " + template.getAbsolutePath(), template.isFile());
        try (ZipFile t = new ZipFile(template)) {
            System.out.println("Template entries:");
            java.util.Enumeration<? extends ZipEntry> en = t.entries();
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                System.out.println("  " + e.getName() + " (method " + e.getMethod() + ", " + e.getSize() + " bytes)");
            }
            byte[] m = ApkGenerator.readAll(t.getInputStream(t.getEntry("AndroidManifest.xml")));
            System.out.println("Template manifest: " + AxmlPatcher.readInfo(m));
        }

        ByteArrayOutputStream zipBytes = new ByteArrayOutputStream();
        try (ZipOutputStream zip = new ZipOutputStream(zipBytes)) {
            add(zip, "my-site/index.html", "<!doctype html><html><head><meta charset=\"utf-8\">"
                    + "<link rel=\"stylesheet\" href=\"css/style.css\"></head><body><h1>Sample app ✓</h1>"
                    + "<script src=\"js/app.js\"></script></body></html>");
            add(zip, "my-site/css/style.css", "body{font-family:sans-serif;background:#eef}");
            add(zip, "my-site/js/app.js", "document.body.insertAdjacentHTML('beforeend','<p>JS works</p>');");
        }
        WebProject project = WebProject.fromAny(zipBytes.toByteArray());
        assertEquals("index.html", project.entry);
        assertEquals(3, project.files.size());

        byte[] png = solidPng(192, 0x15, 0x80, 0x3D);

        ApkGenerator.Options opt = new ApkGenerator.Options();
        opt.appName = "Sample HTML App";
        opt.packageName = "com.htmlapk.sample";
        opt.versionName = "2.5";
        opt.versionCode = 7;
        opt.fullscreen = false;
        opt.iconPng = png;

        CertGen.SigningKey key = CertGen.loadOrCreate(new File("build/test-signing"));
        File out = new File("build/test-output/sample-app.apk");
        assertTrue(out.getParentFile().isDirectory() || out.getParentFile().mkdirs());
        ApkGenerator.generate(template, project, opt, key, out, new File("build/test-work"));
        assertTrue(out.length() > 0);

        try (ZipFile apk = new ZipFile(out)) {
            ZipEntry manifest = apk.getEntry("AndroidManifest.xml");
            assertNotNull(manifest);
            Map<String, String> info = AxmlPatcher.readInfo(ApkGenerator.readAll(apk.getInputStream(manifest)));
            System.out.println("Patched manifest: " + info);
            assertEquals("com.htmlapk.sample", info.get("manifest@package"));
            assertEquals("Sample HTML App", info.get("application@label"));
            assertEquals("2.5", info.get("manifest@versionName"));
            assertEquals("7", info.get("manifest@versionCode"));
            assertNotNull(apk.getEntry("assets/www/index.html"));
            assertNotNull(apk.getEntry("assets/www/css/style.css"));
            assertNotNull(apk.getEntry("assets/htmlapk.properties"));
        }
    }

    /** Writes a plain one-colour PNG without desktop image libraries (not available here). */
    static byte[] solidPng(int size, int r, int g, int b) throws IOException {
        ByteArrayOutputStream raw = new ByteArrayOutputStream();
        for (int y = 0; y < size; y++) {
            raw.write(0); // no filter
            for (int x = 0; x < size; x++) {
                raw.write(r);
                raw.write(g);
                raw.write(b);
                raw.write(255);
            }
        }
        ByteArrayOutputStream idat = new ByteArrayOutputStream();
        try (DeflaterOutputStream z = new DeflaterOutputStream(idat, new Deflater(9))) {
            z.write(raw.toByteArray());
        }
        ByteArrayOutputStream ihdr = new ByteArrayOutputStream();
        DataOutputStream h = new DataOutputStream(ihdr);
        h.writeInt(size);
        h.writeInt(size);
        h.write(new byte[]{8, 6, 0, 0, 0}); // 8-bit RGBA
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        out.write(new byte[]{(byte) 0x89, 'P', 'N', 'G', 13, 10, 26, 10});
        chunk(out, "IHDR", ihdr.toByteArray());
        chunk(out, "IDAT", idat.toByteArray());
        chunk(out, "IEND", new byte[0]);
        return out.toByteArray();
    }

    private static void chunk(ByteArrayOutputStream out, String type, byte[] data) throws IOException {
        DataOutputStream d = new DataOutputStream(out);
        byte[] t = type.getBytes(StandardCharsets.US_ASCII);
        CRC32 crc = new CRC32();
        crc.update(t);
        crc.update(data);
        d.writeInt(data.length);
        d.write(t);
        d.write(data);
        d.writeInt((int) crc.getValue());
    }

    private static void add(ZipOutputStream zip, String name, String text) throws Exception {
        zip.putNextEntry(new ZipEntry(name));
        zip.write(text.getBytes(StandardCharsets.UTF_8));
        zip.closeEntry();
    }
}
